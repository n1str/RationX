package ru.rationx.financeapp.models.dto.auth;

public record RegisterRequest(String username, String password) {} 