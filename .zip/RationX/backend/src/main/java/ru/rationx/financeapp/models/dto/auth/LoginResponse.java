package ru.rationx.financeapp.models.dto.auth;

public record LoginResponse(String token) {}