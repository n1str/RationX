package ru.rationx.financeapp.utils;

public class Util {
}
