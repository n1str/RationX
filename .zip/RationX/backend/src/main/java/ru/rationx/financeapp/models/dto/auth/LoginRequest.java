package ru.rationx.financeapp.models.dto.auth;

public record LoginRequest(String username, String password) {}