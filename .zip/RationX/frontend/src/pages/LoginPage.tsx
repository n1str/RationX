import React from 'react';
import Login from '../components/auth/Login';

const LoginPage: React.FC = () => {
  return <Login />;
};

export default LoginPage;
