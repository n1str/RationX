import React from 'react';
import CategoriesList from '../components/categories/CategoriesList';

const CategoriesPage: React.FC = () => {
  return <CategoriesList />;
};

export default CategoriesPage;
